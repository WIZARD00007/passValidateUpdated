WizzPAVal
* this is a simple project to validate username and password
* this project will be upgraded soon and will be added with new modules. 

usage 
```python
* importing validator function
  from WizzPAVal import autoVal
*running validator
  autoval('username','password')
```
Developing WizzPAVal
* To install WizzPAVal, along with the tools you need to develop
   and run tests, run the following
  in your virtualenv.
```bash
$ pip install -e .[dev]
```
