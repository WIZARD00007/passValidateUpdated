WizzPassVal
* this is a simple project to validate username and password
* this project will be upgraded soon and will be added with new modules. 

usage 
```python
* importing validator function
  from WizzPassVal import autoVal
*running validator
  autoval('username','password')
```
Developing WizzPassVal
* To install WizzPassVal, along with the tools you need to develop
   and run tests, run the following
  in your virtualenv.
```bash
$ pip install -e .[dev]
```
